#pragma once 
#define MAX 100
#include <iostream>
using namespace std;

/*************************************************************/
//                      pila.h
/*************************************************************/
class pila
{
private:
    int Pila[MAX];
    int tope;

public:
    pila();
    bool Apilar(TipoDato& elemento);
    bool Desapilar();
    bool topePila(TipoDato& elemento);
    void LimpiarPila();
    void VerPila();
    bool PilaVacia();
    bool Iguales(Pila p);

};